import streamlit as st
import sys
import os
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import importlib
from datetime import datetime
from typing import Dict, List, Optional, Any
import base64
from io import BytesIO

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Dynamic imports with error handling
try:
    from src import scoring, assessment, report_generator
    importlib.reload(scoring)
    importlib.reload(assessment)
    importlib.reload(report_generator)
except ImportError as e:
    st.error(f"⚠️ Module import error: {e}")
    st.stop()

from src.assessment import run_assessment_v2, load_questions

# ============================================================================
# CONFIGURATION
# ============================================================================

st.set_page_config(
    page_title="AI Readiness Assessment Pro",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# ENHANCED CSS WITH ANIMATIONS
# ============================================================================

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    
    /* Animations */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    /* Score Box Enhanced */
    .score-box {
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        text-align: center;
        border: 1px solid rgba(128, 128, 128, 0.2);
        margin-bottom: 25px;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        animation: fadeIn 0.6s ease-out;
    }
    
    .score-text {
        font-size: 80px !important; 
        font-weight: 800;
        margin: 0;
        line-height: 1.1;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .level-text {
        font-size: 32px !important;
        font-weight: 700;
        margin-top: 10px;
        color: #333;
    }
    
    /* Dimension Cards Enhanced */
    .dimension-card {
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        border: 1px solid #e0e0e0;
        border-radius: 16px;
        padding: 24px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        height: 220px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        position: relative;
        overflow: hidden;
    }
    
    .dimension-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        transform: scaleX(0);
        transition: transform 0.3s ease;
    }
    
    .dimension-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 24px rgba(0,0,0,0.15);
        border-color: #667eea;
    }
    
    .dimension-card:hover::before {
        transform: scaleX(1);
    }
    
    .dim-icon {
        font-size: 36px;
        margin-bottom: 12px;
        transition: transform 0.3s ease;
    }
    
    .dimension-card:hover .dim-icon {
        transform: scale(1.2);
    }
    
    .dim-title {
        font-weight: 700;
        font-size: 18px;
        color: #333;
        margin-bottom: 8px;
    }
    
    .dim-desc {
        font-size: 14px;
        color: #666;
        line-height: 1.5;
    }
    
    /* Recommendation Card Enhanced */
    .recommendation-card {
        padding: 25px;
        border-radius: 12px;
        border-left: 6px solid #667eea;
        margin-bottom: 20px;
        background: linear-gradient(135deg, #f0f7ff 0%, #e8f4f8 100%);
        color: #333;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        transition: all 0.3s ease;
        animation: fadeIn 0.4s ease-out;
    }
    
    .recommendation-card:hover {
        transform: translateX(5px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.12);
    }
    
    .rec-title {
        font-weight: 700;
        color: #667eea;
        font-size: 20px;
        margin-bottom: 10px;
    }
    
    .rec-action {
        font-weight: 600;
        color: #444;
        margin-bottom: 8px;
        font-size: 16px;
    }
    
    /* Progress Bar Enhanced */
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    }
    
    /* Alert Boxes */
    .success-box {
        padding: 20px;
        border-radius: 12px;
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        border-left: 5px solid #28a745;
        margin: 20px 0;
        animation: fadeIn 0.5s ease-out;
    }
    
    .info-box {
        padding: 20px;
        border-radius: 12px;
        background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
        border-left: 5px solid #17a2b8;
        margin: 20px 0;
    }
    
    .warning-box {
        padding: 20px;
        border-radius: 12px;
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        border-left: 5px solid #ffc107;
        margin: 20px 0;
    }
    
    /* Button Enhancements */
    .stButton > button {
        border-radius: 10px;
        font-weight: 600;
        transition: all 0.3s ease;
        border: none;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }
    
    /* Sidebar Styling */
    .sidebar-title-custom {
        font-size: 26px !important;
        font-weight: 800 !important;
        margin-top: -20px;
        margin-bottom: 5px;
        line-height: 1.2;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    /* Loading Spinner */
    .loading-spinner {
        display: inline-block;
        width: 40px;
        height: 40px;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #667eea;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Stats Cards */
    .stat-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border-left: 4px solid #667eea;
        margin: 10px 0;
    }
    
    .stat-number {
        font-size: 32px;
        font-weight: 800;
        color: #667eea;
    }
    
    .stat-label {
        font-size: 14px;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    /* Comparison Table */
    .comparison-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    
    .comparison-table th {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 12px;
        text-align: left;
        font-weight: 600;
    }
    
    .comparison-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .comparison-table tr:hover {
        background-color: #f8f9fa;
    }
    
    h1, h2, h3 {
        color: #111;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# TRANSLATIONS (Enhanced)
# ============================================================================

TRANS = {
    "it": {
        "title": "AI Readiness Assessment Pro", 
        "nav": "Menu",
        "home": "Home",
        "assess": "Assessment",
        "audit": "Data Audit",
        "about": "Informazioni",
        "history": "Cronologia",
        "compare": "Confronta",
        "lang": "💬 Lingua", 
        "examples": "Casi Studio",
        "new": "✨ Nuovo Assessment",
        "hero_title": "Navigare la Trasformazione: AI Readiness Framework",
        "hero_subtitle": "Uno strumento analitico avanzato per misurare la maturità digitale delle organizzazioni e tracciare la rotta verso l'adozione consapevole dell'Intelligenza Artificiale.",
        "met_dim": "Dimensioni Analizzate",
        "met_bench": "Benchmark Settoriali",
        "met_time": "Tempo Stimato",
        "why_title": "Il Modello: 6 Pilastri della Readiness",
        "why_desc": "L'adozione dell'IA non è solo tecnologia. Il nostro framework analizza l'organizzazione a 360 gradi:",
        "d1_t": "Strategia", "d1_d": "Visione aziendale, Business Case e investimenti a lungo termine.",
        "d2_t": "Dati", "d2_d": "Qualità, accessibilità, governance e volume dei dati disponibili.",
        "d3_t": "Processi", "d3_d": "Maturità dei workflow e potenziale di automazione.",
        "d4_t": "Team & Cultura", "d4_d": "Competenze interne (upskilling) e apertura al cambiamento.",
        "d5_t": "Infrastruttura", "d5_d": "Stack tecnologico, Cloud readiness e capacità di integrazione.",
        "d6_t": "Etica & Governance", "d6_d": "Compliance (AI Act), privacy e gestione dei rischi.",
        "method_title": "🔎 Metodologia di Scoring",
        "method": "Metodologia",
        "method_text": "Sistema di scoring ponderato basato su 6 dimensioni chiave.",
        "method_p1": "**Normalizzazione**: Ogni risposta ha un peso specifico. Il punteggio finale (0-100) è calcolato algoritmicamente pesando l'importanza di ogni dimensione.",
        "method_p2": "**Benchmarking**: I tuoi risultati vengono confrontati in tempo reale con standard di settore (es. Manufacturing, Finance, Retail) per evidenziare gap competitivi.",
        "cta_title": "Pronto a iniziare?",
        "start_btn": "🚀 Avvia Assessment",
        "audit_btn": "🔎 Data Audit (Preliminare)",
        "cases_title": "📂 Casi Studio Reali",
        "cases_desc": "Esplora come aziende di diversi settori si posizionano. Clicca per caricare un report completo.",
        "case_1": "Intesa Sanpaolo (Finance)",
        "case_2": "Bauli / FMCG (Retail)",
        "case_3": "PMI Manifatturiera",
        
        "score_title": "Punteggio AI Readiness",
        "sector": "Settore",
        "download": "📄 Scarica Report PDF",
        "download_excel": "📊 Esporta Excel",
        "download_json": "💾 Esporta JSON",
        "share": "🔗 Condividi",
        "save": "💾 Salva Assessment",
        "benchmark": "Benchmark",
        "perf_dim": "Performance per Dimensione",
        "assess_intro": "**Istruzioni**: Rispondi a tutte le domande. Le risposte sono obbligatorie per garantire l'accuratezza del modello.",
        "what_if_title": "🔮 What-If Simulator",
        "what_if_sub": "Pianificazione Strategica",
        "what_if_desc": "Simula l'impatto degli investimenti sul tuo punteggio totale.",
        "sim_total": "Punteggio Simulato",
        "error_answ": "⚠️ Rispondi a tutte le domande per procedere.",
        "reset_btn": "🔄 Reset & Riavvia",
        "autosave": "💾 Salvataggio automatico attivo",
        
        "rec_title": "💡 Roadmap Strategica",
        "empty_rec": "Ottimo lavoro! Nessuna raccomandazione critica.",
        "all_done": "🎉 Assessment Completato!",
        "audit_title": "Data Audit Checklist",
        "audit_desc": "Check rapido sulla salute dei dati.",
        "audit_score": "Indice Maturità Dati",
        "audit_low": "⚠️ Silos Informativi", 
        "audit_med": "📈 Digitalizzazione Reattiva", 
        "audit_high": "🚀 Data Governance Proattiva",
        "go_to_assess": "Vai all'Assessment →",
        "about_text": "Sviluppato da Sabrina Rizzi.",
        "contact": "Contatti",
        "history_title": "📊 Cronologia Assessment",
        "history_empty": "Nessun assessment salvato. Completa il tuo primo assessment!",
        "compare_title": "📊 Confronto Assessment",
        "compare_desc": "Confronta fino a 3 assessment per tracciare i progressi",
        "loading": "Caricamento in corso...",
        "error_generic": "Si è verificato un errore. Riprova.",
        "success_save": "✅ Assessment salvato con successo!",
        "confirm_reset": "Sei sicuro di voler resettare? Tutti i dati non salvati andranno persi.",
    },
    "en": {
        "title": "AI Readiness Assessment Pro",
        "nav": "Menu",
        "home": "Home",
        "assess": "Assessment",
        "audit": "Data Audit",
        "about": "About",
        "history": "History",
        "compare": "Compare",
        "lang": "💬 Language",
        "examples": "Case Studies",
        "new": "✨ New Assessment",
        "hero_title": "Navigating Transformation: AI Readiness Framework",
        "hero_subtitle": "An advanced analytic tool to measure digital maturity and chart the course towards conscious AI adoption.",
        "met_dim": "Dimensions Analyzed",
        "met_bench": "Sector Benchmarks",
        "met_time": "Est. Time",
        "why_title": "The Model: 6 Pillars of Readiness",
        "why_desc": "AI adoption is not just tech. Our framework analyzes the organization 360 degrees:",
        "d1_t": "Strategy", "d1_d": "Business vision, ROI definition, and long-term investment.",
        "d2_t": "Data", "d2_d": "Quality, accessibility, governance, and volume.",
        "d3_t": "Processes", "d3_d": "Workflow maturity and automation potential.",
        "d4_t": "Team & Culture", "d4_d": "Internal skills (upskilling) and change management.",
        "d5_t": "Infrastructure", "d5_d": "Tech stack, Cloud readiness, and integration.",
        "d6_t": "Ethics & Governance", "d6_d": "Compliance (AI Act), privacy, and risk management.",
        "method_title": "🔎 Scoring Methodology",
        "method": "Methodology",
        "method_text": "Weighted scoring system based on 6 key dimensions.",
        "method_p1": "**Normalization**: Each question has a weight. The final score (0-100) is calculated algorithmically.",
        "method_p2": "**Benchmarking**: Your results are compared in real-time with industry standards to highlight competitive gaps.",
        "cta_title": "Ready to start?",
        "start_btn": "🚀 Start Assessment",
        "audit_btn": "🔎 Data Audit (Preliminary)",
        "cases_title": "📂 Real-World Case Studies",
        "cases_desc": "Explore how different companies perform. Click to load a full report.",
        "case_1": "Intesa Sanpaolo (Finance)",
        "case_2": "Bauli / FMCG (Retail)",
        "case_3": "Manufacturing SME",
        
        "score_title": "AI Readiness Score",
        "sector": "Sector",
        "download": "📄 Download PDF Report",
        "download_excel": "📊 Export Excel",
        "download_json": "💾 Export JSON",
        "share": "🔗 Share",
        "save": "💾 Save Assessment",
        "benchmark": "Benchmark",
        "perf_dim": "Performance by Dimension",
        "assess_intro": "**Instructions**: Answer all questions honestly.",
        "what_if_title": "🔮 What-If Simulator",
        "what_if_sub": "Strategic Planning",
        "what_if_desc": "Simulate investment impact on your total score.",
        "sim_total": "Simulated Score",
        "error_answ": "⚠️ Please answer all questions.",
        "reset_btn": "🔄 Reset & Restart",
        "autosave": "💾 Auto-save active",
        
        "rec_title": "💡 Strategic Roadmap",
        "empty_rec": "Great job! No critical recommendations.",
        "all_done": "🎉 Assessment Completed!",
        "audit_title": "Data Audit Checklist",
        "audit_desc": "Quick data health check.",
        "audit_score": "Data Maturity Index",
        "audit_low": "⚠️ Data Silos", 
        "audit_med": "📈 Reactive Digitalization", 
        "audit_high": "🚀 Proactive Governance",
        "go_to_assess": "Go to Assessment →",
        "about_text": "Developed by Sabrina Rizzi.",
        "contact": "Contact",
        "history_title": "📊 Assessment History",
        "history_empty": "No saved assessments. Complete your first assessment!",
        "compare_title": "📊 Compare Assessments",
        "compare_desc": "Compare up to 3 assessments to track progress",
        "loading": "Loading...",
        "error_generic": "An error occurred. Please try again.",
        "success_save": "✅ Assessment saved successfully!",
        "confirm_reset": "Are you sure you want to reset? All unsaved data will be lost.",
    }
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def load_benchmarks() -> Dict:
    """Load sector benchmarks from JSON file."""
    try:
        with open('data/benchmarks.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        st.warning("⚠️ Benchmark file not found. Using defaults.")
        return {
            "General": {"strategy": 50, "data": 50, "processes": 50, 
                       "team": 50, "infrastructure": 50, "ethics": 50},
            "Manufacturing": {"strategy": 55, "data": 60, "processes": 65, 
                             "team": 50, "infrastructure": 55, "ethics": 50},
            "Finance": {"strategy": 70, "data": 75, "processes": 65, 
                       "team": 60, "infrastructure": 70, "ethics": 80},
            "FMCG": {"strategy": 60, "data": 65, "processes": 60, 
                    "team": 55, "infrastructure": 60, "ethics": 65},
            "Retail": {"strategy": 55, "data": 60, "processes": 60, 
                      "team": 50, "infrastructure": 55, "ethics": 60}
        }
    except Exception as e:
        st.error(f"Error loading benchmarks: {e}")
        return {}

def save_assessment_to_history(results: Dict, sector: str, lang: str) -> None:
    """Save assessment to history with timestamp."""
    if 'assessment_history' not in st.session_state:
        st.session_state.assessment_history = []
    
    assessment_record = {
        'timestamp': datetime.now().isoformat(),
        'results': results,
        'sector': sector,
        'lang': lang,
        'answers': st.session_state.get('answers', {})
    }
    
    st.session_state.assessment_history.append(assessment_record)
    
    # Keep only last 10 assessments
    if len(st.session_state.assessment_history) > 10:
        st.session_state.assessment_history = st.session_state.assessment_history[-10:]

def export_to_excel(results: Dict, sector: str) -> BytesIO:
    """Export assessment results to Excel format."""
    output = BytesIO()
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        # Summary sheet
        summary_data = {
            'Metric': ['Total Score', 'Level', 'Sector', 'Date'],
            'Value': [
                results['total_score'],
                results['level'],
                sector,
                datetime.now().strftime('%Y-%m-%d %H:%M')
            ]
        }
        pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)
        
        # Dimensions sheet
        dim_data = []
        for dim_id, dim_info in results['dimensions'].items():
            dim_data.append({
                'Dimension': dim_info['name'],
                'Score': dim_info['score'],
                'Weight': dim_info.get('weight', 1.0)
            })
        pd.DataFrame(dim_data).to_excel(writer, sheet_name='Dimensions', index=False)
        
        # Recommendations sheet
        if 'detailed_recommendations' in results:
            rec_data = []
            for rec in results['detailed_recommendations']:
                rec_data.append({
                    'Dimension': rec['dimension'],
                    'Action': rec['action'],
                    'Detail': rec['detail']
                })
            pd.DataFrame(rec_data).to_excel(writer, sheet_name='Recommendations', index=False)
    
    output.seek(0)
    return output

def export_to_json(results: Dict, sector: str, answers: Dict) -> str:
    """Export complete assessment to JSON format."""
    export_data = {
        'metadata': {
            'timestamp': datetime.now().isoformat(),
            'sector': sector,
            'version': '2.0'
        },
        'results': results,
        'answers': answers
    }
    return json.dumps(export_data, indent=2, ensure_ascii=False)

def create_comparison_chart(assessments: List[Dict], t: Dict) -> go.Figure:
    """Create comparison chart for multiple assessments."""
    fig = go.Figure()
    
    colors = ['#667eea', '#f093fb', '#4facfe']
    
    for idx, assessment in enumerate(assessments):
        results = assessment['results']
        timestamp = datetime.fromisoformat(assessment['timestamp']).strftime('%Y-%m-%d %H:%M')
        
        categories = [dim['name'] for dim in results['dimensions'].values()]
        values = [dim['score'] for dim in results['dimensions'].values()]
        
        categories_closed = categories + [categories[0]]
        values_closed = values + [values[0]]
        
        fig.add_trace(go.Scatterpolar(
            r=values_closed,
            theta=categories_closed,
            fill='toself',
            name=f"Assessment {idx + 1} ({timestamp})",
            line_color=colors[idx % len(colors)]
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 100],
                gridcolor="#e0e0e0",
                tickfont=dict(size=12)
            )
        ),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        margin=dict(l=40, r=40, t=20, b=80),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)"
    )
    
    return fig

def auto_save_answers() -> None:
    """Auto-save current answers to session state."""
    if 'answers' in st.session_state and st.session_state.answers:
        st.session_state.last_autosave = datetime.now()

def load_example_data_and_redirect(example_name: str, menu_options: Dict, t: Dict) -> None:
    """Load example data from JSON file and redirect to assessment."""
    file_map = {
        "Intesa Sanpaolo (High)": "examples/intesa_sanpaolo.json",
        "Intesa Sanpaolo (Finance)": "examples/intesa_sanpaolo.json",
        "Italian SME (Medium)": "examples/italian_sme.json",
        "Manufacturing SME": "examples/italian_sme.json",
        "Tradizione Casa (Low)": "examples/low_readiness.json",
        "Bauli / FMCG (Retail)": "examples/intesa_sanpaolo.json",
    }
    
    file_path = file_map.get(example_name)
    
    if not file_path:
        if "Intesa" in example_name or "Bauli" in example_name:
            file_path = "examples/intesa_sanpaolo.json"
        elif "SME" in example_name:
            file_path = "examples/italian_sme.json"
    
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                st.session_state.answers = data.get('answers', {})
                st.session_state.data_uid = st.session_state.get('data_uid', 0) + 1
                st.session_state.last_loaded_example = example_name
                st.session_state.menu = "Assessment"
                st.session_state.show_results = True
                
                try:
                    assess_label = next(k for k, v in menu_options.items() if v == "Assessment")
                    st.session_state.nav_radio = assess_label
                except:
                    pass
                
                st.rerun()
        except Exception as e:
            st.error(f"Error loading example: {e}")
    else:
        st.warning(f"Example file not found: {file_path}")

# ============================================================================
# MAIN APPLICATION
# ============================================================================

def main():
    """Main application entry point."""
    # Initialize session state
    if 'menu' not in st.session_state:
        st.session_state.menu = "Home"
    if 'data_uid' not in st.session_state:
        st.session_state.data_uid = 0
    if 'show_results' not in st.session_state:
        st.session_state.show_results = False
    if 'assessment_history' not in st.session_state:
        st.session_state.assessment_history = []
    
    # Sidebar
    st.sidebar.markdown(
        f"<p class='sidebar-title-custom'>🤖 {TRANS['en']['title']}</p>", 
        unsafe_allow_html=True
    )
    
    st.sidebar.markdown("""
    <div style='font-size: 0.9em; color: #666; margin-top: -10px; margin-bottom: 20px;'>
    | Sabrina Rizzi
    </div>
    <div class='sidebar-link'>
    <a href="https://sabrina-rizzi.github.io/" target="_blank">🌐 Website</a> | 
    <a href="http://www.linkedin.com/in/sabrina-rizzi14" target="_blank">🔗 LinkedIn</a>
    </div>
    """, unsafe_allow_html=True)
    
    st.sidebar.markdown("<br>", unsafe_allow_html=True)
    
    # Language selector
    lang_code = st.sidebar.radio(
        "💬 Language", 
        ["IT", "EN"], 
        horizontal=True, 
        key="lang_toggle"
    )
    lang = lang_code.lower()
    t = TRANS[lang]
    
    st.sidebar.markdown("---")
    
    # Sector selector
    st.sidebar.subheader(f"🏢 {t['sector']}")
    sector_options = ["General", "Manufacturing", "Finance", "FMCG", "Retail"]
    selected_sector = st.sidebar.selectbox(
        "Select Sector", 
        sector_options, 
        key="sector_select", 
        label_visibility="collapsed"
    )
    
    st.sidebar.markdown("---")
    
    # Navigation menu
    menu_options = {
        t['home']: "Home",
        t['audit']: "Data Audit",
        t['assess']: "Assessment",
        t['history']: "History",
        t['compare']: "Compare",
        t['about']: "About"
    }
    
    def handle_menu():
        st.session_state.menu = menu_options[st.session_state.nav_radio]
        if st.session_state.menu != "Assessment":
            st.session_state.show_results = False
    
    current_labels = list(menu_options.keys())
    try:
        current_label = next(k for k, v in menu_options.items() if v == st.session_state.menu)
    except StopIteration:
        current_label = t['home']
        st.session_state.menu = "Home"
    
    st.session_state.nav_radio = current_label
    st.sidebar.markdown(f"### 🧭 {t['nav']}")
    st.sidebar.radio(
        t['nav'], 
        current_labels, 
        key="nav_radio", 
        on_change=handle_menu, 
        label_visibility="collapsed"
    )
    
    st.sidebar.markdown("---")
    
    # Examples selector
    st.sidebar.subheader(f"📂 {t['examples']}")
    example_options = [
        t['new'], 
        "Intesa Sanpaolo (High)", 
        "Italian SME (Medium)", 
        "Tradizione Casa (Low)"
    ]
    selected_example = st.sidebar.selectbox(
        f"{t['examples']}:", 
        example_options, 
        key=f"ex_box_{lang}", 
        label_visibility="collapsed"
    )
    
    if selected_example != t['new']:
        if st.session_state.get('last_loaded_example') != selected_example:
            load_example_data_and_redirect(selected_example, menu_options, t)
    
    st.sidebar.markdown("---")
    
    # Reset button with confirmation
    if st.sidebar.button(t['reset_btn'], type="secondary"):
        if st.sidebar.checkbox(t['confirm_reset'], key="confirm_reset_check"):
            st.session_state.clear()
            st.rerun()
    
    # Auto-save indicator
    if 'last_autosave' in st.session_state:
        last_save = st.session_state.last_autosave.strftime('%H:%M:%S')
        st.sidebar.markdown(f"<div style='font-size: 0.8em; color: #28a745;'>💾 {t['autosave']}<br>Last: {last_save}</div>", unsafe_allow_html=True)
    
    # Load questions
    questions_data = load_questions()
    
    # Route to appropriate page
    menu = st.session_state.menu
    
    if menu == "Home":
        show_home(t, menu_options)
    elif menu == "Assessment":
        show_assessment(questions_data, t, lang, selected_sector)
    elif menu == "Data Audit":
        show_data_audit(t, lang, menu_options)
    elif menu == "History":
        show_history(t, lang)
    elif menu == "Compare":
        show_compare(t, lang)
    elif menu == "About":
        show_about(t)

# ============================================================================
# PAGE FUNCTIONS
# ============================================================================

def show_home(t: Dict, menu_options: Dict) -> None:
    """Display home page."""
    # Hero section
    st.title("🚀 " + t['hero_title'])
    st.markdown(f"### {t['hero_subtitle']}")
    
    # Metrics
    m1, m2, m3 = st.columns(3)
    m1.metric("📊 " + t['met_dim'], "6 Pilastri")
    m2.metric("🏢 " + t['met_bench'], "5 Settori")
    m3.metric("⏱️ " + t['met_time'], "5-7 min")
    
    st.markdown("---")
    
    # Dimensions grid
    st.subheader(t['why_title'])
    st.markdown(t['why_desc'])
    
    # Row 1
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>🎯</div>"
            f"<div class='dim-title'>{t['d1_t']}</div>"
            f"<div class='dim-desc'>{t['d1_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    with c2:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>💾</div>"
            f"<div class='dim-title'>{t['d2_t']}</div>"
            f"<div class='dim-desc'>{t['d2_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    with c3:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>⚙️</div>"
            f"<div class='dim-title'>{t['d3_t']}</div>"
            f"<div class='dim-desc'>{t['d3_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Row 2
    c4, c5, c6 = st.columns(3)
    with c4:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>👥</div>"
            f"<div class='dim-title'>{t['d4_t']}</div>"
            f"<div class='dim-desc'>{t['d4_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    with c5:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>☁️</div>"
            f"<div class='dim-title'>{t['d5_t']}</div>"
            f"<div class='dim-desc'>{t['d5_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    with c6:
        st.markdown(
            f"<div class='dimension-card'>"
            f"<div class='dim-icon'>⚖️</div>"
            f"<div class='dim-title'>{t['d6_t']}</div>"
            f"<div class='dim-desc'>{t['d6_d']}</div>"
            f"</div>", 
            unsafe_allow_html=True
        )
    
    st.markdown("---")
    
    # Methodology and actions
    col_met, col_act = st.columns([1.5, 1])
    
    with col_met:
        st.subheader(t['method_title'])
        st.info(t['method_p1'])
        st.info(t['method_p2'])
    
    with col_act:
        st.markdown(f"### {t['cta_title']}")
        
        def go_assess():
            st.session_state.menu = "Assessment"
            try:
                assess_label = next(k for k, v in menu_options.items() if v == "Assessment")
                st.session_state.nav_radio = assess_label
            except:
                pass
        
        def go_audit():
            st.session_state.menu = "Data Audit"
            try:
                audit_label = next(k for k, v in menu_options.items() if v == "Data Audit")
                st.session_state.nav_radio = audit_label
            except:
                pass
        
        st.button(t['start_btn'], on_click=go_assess, type="primary", use_container_width=True)
        st.markdown("")
        st.button(t['audit_btn'], on_click=go_audit, type="secondary", use_container_width=True)
    
    st.markdown("---")
    
    # Case studies
    st.subheader(t['cases_title'])
    st.markdown(t['cases_desc'])
    
    cc1, cc2, cc3 = st.columns(3)
    with cc1:
        if st.button(t['case_1'], use_container_width=True):
            load_example_data_and_redirect("Intesa Sanpaolo (High)", menu_options, t)
    with cc2:
        if st.button(t['case_2'], use_container_width=True):
            load_example_data_and_redirect("Bauli / FMCG (Retail)", menu_options, t)
    with cc3:
        if st.button(t['case_3'], use_container_width=True):
            load_example_data_and_redirect("Italian SME (Medium)", menu_options, t)

def show_assessment(questions_data: Dict, t: Dict, lang: str, sector: str) -> None:
    """Display assessment page with questions."""
    st.title(f"{t['assess']} - {sector}")
    st.markdown(t['assess_intro'])
    
    if 'answers' not in st.session_state:
        st.session_state.answers = {}
    
    # Filter dimensions based on sector
    active_dims = [
        d for d in questions_data['dimensions'] 
        if not (d['id'] == 'fmcg' and sector != 'FMCG')
    ]
    
    # Calculate progress
    total_questions = sum(len(d['questions']) for d in active_dims)
    answered_real = 0
    
    for dim in active_dims:
        if dim['id'] in st.session_state.answers:
            valid_ans = [a for a in st.session_state.answers[dim['id']] if a is not None]
            answered_real += len(valid_ans)
    
    progress = min(answered_real / total_questions, 1.0) if total_questions > 0 else 0
    st.progress(progress, text=f"Progress: {int(progress*100)}%")
    
    # Assessment form
    with st.form(f"assessment_form_{lang}"):
        temp_answers = {}
        all_answered = True
        
        for dim in active_dims:
            dim_name = dim['name'] if lang == 'it' else dim.get('name_en', dim['name'])
            dim_desc = dim['description'] if lang == 'it' else dim.get('description_en', dim['description'])
            
            st.header(f"📍 {dim_name}")
            with st.expander(f"ℹ️ {dim_name}: Info"):
                st.write(dim_desc)
            
            dim_answers = []
            for i, q in enumerate(dim['questions']):
                default_idx = None
                if dim['id'] in st.session_state.answers:
                    if i < len(st.session_state.answers[dim['id']]):
                        saved_score = st.session_state.answers[dim['id']][i]
                        opt_scores = [o['score'] for o in q['options']]
                        if saved_score in opt_scores:
                            default_idx = opt_scores.index(saved_score)
                
                q_text = q['text'] if lang == 'it' else q.get('text_en', q['text'])
                st.markdown(f"#### {q_text}")
                
                ops_labels = []
                ops_scores = []
                for opt in q['options']:
                    ops_labels.append(opt['text'] if lang == 'it' else opt.get('text_en', opt['text']))
                    ops_scores.append(opt['score'])
                
                uid = st.session_state.get('data_uid', 0)
                choice = st.radio(
                    f"Select option {i} {dim['id']}", 
                    options=ops_labels,
                    index=default_idx, 
                    key=f"{dim['id']}_{i}_{lang}_{uid}_{sector}", 
                    label_visibility="collapsed"
                )
                
                if choice is None:
                    all_answered = False
                    dim_answers.append(None)
                else:
                    score = ops_scores[ops_labels.index(choice)]
                    dim_answers.append(score)
                
                st.markdown("<br>", unsafe_allow_html=True)
            
            temp_answers[dim['id']] = dim_answers
            st.markdown("---")
        
        # Submit button
        col1, col2 = st.columns([3, 1])
        with col1:
            submitted = st.form_submit_button(f"🏁 {t['assess']}", type="primary", use_container_width=True)
        with col2:
            save_draft = st.form_submit_button(t['save'], type="secondary", use_container_width=True)
        
        if submitted:
            if not all_answered:
                st.error(t['error_answ'])
            else:
                st.session_state.answers = temp_answers
                st.session_state.show_results = True
                auto_save_answers()
                st.rerun()
        
        if save_draft:
            st.session_state.answers = temp_answers
            auto_save_answers()
            st.success(t['success_save'])
    
    # Show results if available
    if st.session_state.get('show_results', False):
        try:
            from src import assessment
            results = assessment.run_assessment_v2(st.session_state.answers, lang=lang)
            show_results(results, t, sector, lang)
        except Exception as e:
            st.error(f"Error calculating results: {e}")

def show_results(results: Dict, t: Dict, sector: str, lang: str) -> None:
    """Display assessment results with enhanced visualizations."""
    st.balloons()
    st.markdown(f"<div class='success-box'><h2>{t['all_done']}</h2></div>", unsafe_allow_html=True)
    
    col1, col2 = st.columns([1, 1.2])
    
    with col1:
        st.subheader(t.get('score_title', "Score"))
        score = int(results['total_score'])
        color = "#dc3545" if score < 40 else "#efb700" if score < 70 else "#28a745"
        
        st.markdown(
            f"<div class='score-box'>"
            f"<p class='score-text' style='color: {color};'>{score}/100</p>"
            f"<p class='level-text'>{results['level']}</p>"
            f"</div>", 
            unsafe_allow_html=True
        )
        
        st.info(results['recommendation'])
        
        # Download buttons
        st.markdown("### 📥 Export Options")
        
        col_pdf, col_excel, col_json = st.columns(3)
        
        with col_pdf:
            if st.button(t['download'], use_container_width=True):
                try:
                    from src.report_generator import generate_pdf
                    pdf_bytes = generate_pdf(results, sector, lang=lang)
                    st.download_button(
                        "📥 Download PDF", 
                        data=pdf_bytes, 
                        file_name=f"ai_readiness_{datetime.now().strftime('%Y%m%d')}.pdf", 
                        mime="application/pdf",
                        use_container_width=True
                    )
                except Exception as e:
                    st.error(f"PDF error: {e}")
        
        with col_excel:
            if st.button(t['download_excel'], use_container_width=True):
                try:
                    excel_bytes = export_to_excel(results, sector)
                    st.download_button(
                        "📥 Download Excel", 
                        data=excel_bytes, 
                        file_name=f"ai_readiness_{datetime.now().strftime('%Y%m%d')}.xlsx", 
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        use_container_width=True
                    )
                except Exception as e:
                    st.error(f"Excel error: {e}")
        
        with col_json:
            if st.button(t['download_json'], use_container_width=True):
                json_str = export_to_json(results, sector, st.session_state.get('answers', {}))
                st.download_button(
                    "📥 Download JSON", 
                    data=json_str, 
                    file_name=f"ai_readiness_{datetime.now().strftime('%Y%m%d')}.json", 
                    mime="application/json",
                    use_container_width=True
                )
        
        # Save to history button
        if st.button(f"💾 {t['save']}", type="primary", use_container_width=True):
            save_assessment_to_history(results, sector, lang)
            st.success(t['success_save'])
    
    with col2:
        st.subheader(t['perf_dim'])
        
        categories = [dim['name'] for dim in results['dimensions'].values()]
        values = [dim['score'] for dim in results['dimensions'].values()]
        
        benchmarks = load_benchmarks()
        sector_bench = benchmarks.get(sector, benchmarks.get('General', {}))
        bench_values = [sector_bench.get(dim_id, 0) for dim_id in results['dimensions'].keys()]
        
        categories_closed = categories + [categories[0]]
        values_closed = values + [values[0]]
        bench_closed = bench_values + [bench_values[0]]
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatterpolar(
            r=values_closed, 
            theta=categories_closed, 
            fill='toself', 
            name='Your Score',
            line_color='#667eea',
            fillcolor='rgba(102, 126, 234, 0.3)'
        ))
        
        fig.add_trace(go.Scatterpolar(
            r=bench_closed, 
            theta=categories_closed, 
            fill='toself', 
            name=f"{t['benchmark']} ({sector})",
            line_color='#ffc107',
            fillcolor='rgba(255, 193, 7, 0.2)'
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True, 
                    range=[0, 100], 
                    gridcolor="#e0e0e0",
                    tickfont=dict(size=12)
                )
            ),
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2),
            margin=dict(l=40, r=40, t=20, b=50),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)"
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("---")
    
    # What-If Simulator
    with st.expander(t['what_if_title'], expanded=True):
        st.subheader(t['what_if_sub'])
        st.markdown(t['what_if_desc'])
        
        current_dims = results['dimensions']
        weighted_sim_sum = 0
        total_sim_weight = 0
        
        cols = st.columns(3)
        for i, (d_id, d_val) in enumerate(current_dims.items()):
            with cols[i % 3]:
                val = int(d_val['score'])
                new_val = st.slider(
                    f"{d_val['name']}", 
                    0, 100, val, 
                    key=f"sim_{d_id}"
                )
                
                w = d_val.get('weight', 1.0)
                weighted_sim_sum += new_val * w
                total_sim_weight += w
        
        if total_sim_weight > 0:
            sim_total = weighted_sim_sum / total_sim_weight
            sim_total = min(100, max(0, sim_total))
            delta = int(sim_total - score)
            
            st.markdown("---")
            col_sim1, col_sim2 = st.columns(2)
            with col_sim1:
                st.metric(t['sim_total'], f"{int(sim_total)}/100", delta=f"{delta:+d}")
            with col_sim2:
                impact_pct = (delta / score * 100) if score > 0 else 0
                st.metric("Impact", f"{impact_pct:+.1f}%")
    
    st.markdown("---")
    
    # Strategic Roadmap
    st.subheader(t['rec_title'])
    detailed_recs = results.get('detailed_recommendations', [])
    
    if detailed_recs:
        rec_cols = st.columns(2)
        for idx, rec in enumerate(detailed_recs):
            with rec_cols[idx % 2]:
                st.markdown(
                    f"<div class='recommendation-card'>"
                    f"<div class='rec-title'>📍 {rec['dimension']}</div>"
                    f"<div class='rec-action'>👉 {rec['action']}</div>"
                    f"<div style='font-size: 14px; margin-top: 8px;'>{rec['detail']}</div>"
                    f"</div>", 
                    unsafe_allow_html=True
                )
    else:
        st.markdown(f"<div class='info-box'>{t['empty_rec']}</div>", unsafe_allow_html=True)

def show_data_audit(t: Dict, lang: str, menu_options: Dict) -> None:
    """Display data audit checklist page."""
    st.title(t['audit_title'])
    st.markdown(t['audit_desc'])
    
    try:
        with open('data/data_audit.json', 'r', encoding='utf-8') as f:
            audit_data = json.load(f)
        
        checked_count = 0
        total_questions = 0
        
        for section in audit_data['sections']:
            title = section['title'] if lang == 'it' else section.get('title_en', section['title'])
            st.subheader(title)
            
            questions = section['questions']
            for q in questions:
                total_questions += 1
                q_text = q['text'] if isinstance(q, dict) else q
                if isinstance(q, dict):
                    q_text = q['text'] if lang == 'it' else q.get('text_en', q['text'])
                
                if st.checkbox(q_text, key=f"audit_{total_questions}_{lang}"):
                    checked_count += 1
            
            st.markdown("---")
        
        if st.button(t['audit_btn'], key=f"audit_calc_btn_{lang}", type="primary"):
            score = int((checked_count / total_questions) * 100) if total_questions > 0 else 0
            
            st.markdown(f"### 📊 {t['audit_score']}: {score}%")
            
            if score < 35:
                feedback = t['audit_low']
                color = "#dc3545"
            elif score < 75:
                feedback = t['audit_med']
                color = "#ffc107"
            else:
                feedback = t['audit_high']
                color = "#28a745"
            
            st.markdown(
                f"<div style='padding: 20px; border-radius: 12px; "
                f"background-color: {color}20; border-left: 5px solid {color};'>"
                f"<h3 style='color: {color}; margin: 0;'>{feedback}</h3>"
                f"</div>", 
                unsafe_allow_html=True
            )
            
            if score >= 35:
                def go_to_assessment():
                    st.session_state.menu = "Assessment"
                    st.session_state.show_results = False
                    try:
                        assess_label = next(k for k, v in menu_options.items() if v == "Assessment")
                        st.session_state.nav_radio = assess_label
                    except:
                        pass
                
                st.markdown("<br>", unsafe_allow_html=True)
                st.button(
                    t['go_to_assess'], 
                    key=f"redir_{lang}", 
                    on_click=go_to_assessment, 
                    type="primary",
                    use_container_width=True
                )
    
    except FileNotFoundError:
        st.error("Data audit file not found. Please create 'data/data_audit.json'")
    except Exception as e:
        st.error(f"Error: {e}")

def show_history(t: Dict, lang: str) -> None:
    """Display assessment history page."""
    st.title(t['history_title'])
    
    if not st.session_state.get('assessment_history', []):
        st.markdown(f"<div class='info-box'>{t['history_empty']}</div>", unsafe_allow_html=True)
        return
    
    # Display assessment history
    for idx, assessment in enumerate(reversed(st.session_state.assessment_history)):
        timestamp = datetime.fromisoformat(assessment['timestamp'])
        results = assessment['results']
        sector = assessment.get('sector', 'General')
        
        with st.expander(
            f"📊 Assessment #{len(st.session_state.assessment_history) - idx} - "
            f"{timestamp.strftime('%Y-%m-%d %H:%M')} - Score: {int(results['total_score'])}/100",
            expanded=(idx == 0)
        ):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Score", f"{int(results['total_score'])}/100")
            with col2:
                st.metric("Level", results['level'])
            with col3:
                st.metric("Sector", sector)
            
            st.markdown("#### Dimension Scores")
            dim_data = []
            for dim_id, dim_info in results['dimensions'].items():
                dim_data.append({
                    'Dimension': dim_info['name'],
                    'Score': f"{int(dim_info['score'])}/100"
                })
            
            df = pd.DataFrame(dim_data)
            st.dataframe(df, use_container_width=True, hide_index=True)
            
            # Action buttons
            col_load, col_delete = st.columns(2)
            
            with col_load:
                if st.button(
                    "📂 Load This Assessment", 
                    key=f"load_{idx}", 
                    use_container_width=True
                ):
                    st.session_state.answers = assessment.get('answers', {})
                    st.session_state.menu = "Assessment"
                    st.session_state.show_results = True
                    st.rerun()
            
            with col_delete:
                if st.button(
                    "🗑️ Delete", 
                    key=f"delete_{idx}", 
                    type="secondary",
                    use_container_width=True
                ):
                    actual_idx = len(st.session_state.assessment_history) - 1 - idx
                    st.session_state.assessment_history.pop(actual_idx)
                    st.rerun()

def show_compare(t: Dict, lang: str) -> None:
    """Display comparison page for multiple assessments."""
    st.title(t['compare_title'])
    st.markdown(t['compare_desc'])
    
    if len(st.session_state.get('assessment_history', [])) < 2:
        st.warning("You need at least 2 saved assessments to compare. Complete more assessments first!")
        return
    
    # Select assessments to compare
    st.markdown("### Select Assessments to Compare (max 3)")
    
    assessment_options = []
    for idx, assessment in enumerate(st.session_state.assessment_history):
        timestamp = datetime.fromisoformat(assessment['timestamp'])
        score = int(assessment['results']['total_score'])
        assessment_options.append(
            f"#{idx + 1} - {timestamp.strftime('%Y-%m-%d %H:%M')} - Score: {score}/100"
        )
    
    selected_indices = st.multiselect(
        "Select up to 3 assessments:",
        options=range(len(assessment_options)),
        format_func=lambda x: assessment_options[x],
        max_selections=3
    )
    
    if len(selected_indices) >= 2:
        selected_assessments = [
            st.session_state.assessment_history[i] for i in selected_indices
        ]
        
        # Comparison radar chart
        st.markdown("### 📊 Comparison Chart")
        fig = create_comparison_chart(selected_assessments, t)
        st.plotly_chart(fig, use_container_width=True)
        
        # Comparison table
        st.markdown("### 📋 Detailed Comparison")
        
        comparison_data = []
        for idx, assessment in enumerate(selected_assessments):
            results = assessment['results']
            timestamp = datetime.fromisoformat(assessment['timestamp'])
            
            row = {
                'Assessment': f"#{selected_indices[idx] + 1}",
                'Date': timestamp.strftime('%Y-%m-%d'),
                'Total Score': int(results['total_score']),
                'Level': results['level']
            }
            
            for dim_id, dim_info in results['dimensions'].items():
                row[dim_info['name']] = int(dim_info['score'])
            
            comparison_data.append(row)
        
        df = pd.DataFrame(comparison_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        # Progress analysis
        if len(selected_assessments) >= 2:
            st.markdown("### 📈 Progress Analysis")
            
            first_score = int(selected_assessments[0]['results']['total_score'])
            last_score = int(selected_assessments[-1]['results']['total_score'])
            improvement = last_score - first_score
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("First Score", f"{first_score}/100")
            with col2:
                st.metric("Latest Score", f"{last_score}/100", delta=f"{improvement:+d}")
            with col3:
                improvement_pct = (improvement / first_score * 100) if first_score > 0 else 0
                st.metric("Improvement", f"{improvement_pct:+.1f}%")

def show_about(t: Dict) -> None:
    """Display about page."""
    st.title(t['about'])
    
    st.markdown(f"""
    {t['about_text']}
    
    ### 🏗️ {t['method']}
    {t['method_text']}
    
    ### ✨ Features
    - **6 Comprehensive Dimensions**: Strategy, Data, Processes, Team, Infrastructure, Ethics
    - **Multi-language Support**: Italian & English
    - **Sector Benchmarking**: Compare against industry standards
    - **What-If Simulator**: Plan strategic improvements
    - **Assessment History**: Track progress over time
    - **Multiple Export Formats**: PDF, Excel, JSON
    - **Auto-save**: Never lose your progress
    - **Comparison Tools**: Compare multiple assessments
    
    ### 🤝 {t['contact']}
    - **Sabrina Rizzi**: Aspiring AI Developer & Data Analyst
    - [🌐 Professional Website](https://sabrina-rizzi.github.io/)
    - [🔗 LinkedIn Profile](http://www.linkedin.com/in/sabrina-rizzi14)
    
    ### 📝 Version
    **AI Readiness Assessment Pro v2.0**
    - Enhanced UI/UX with animations
    - Improved error handling
    - Assessment history and comparison
    - Multiple export formats
    - Auto-save functionality
    """)

# ============================================================================
# RUN APPLICATION
# ============================================================================

if __name__ == "__main__":
    main()
